document.getElementById("portfolio-form").addEventListener("submit", async function(event) {
    event.preventDefault();
    const formData = {
        monthly_income: document.getElementById("monthly-income").value,
        monthly_expenses: document.getElementById("monthly-expenses").value,
        total_debts: document.getElementById("total-debts").value,
        total_assets: document.getElementById("total-assets").value,
        financial_goals: document.getElementById("financial-goals").value,
        risk_tolerance: document.getElementById("risk-tolerance").value,
        current_investments: document.getElementById("current-investments").value,
        other_info: document.getElementById("other-info").value
    };

    try {
        const response = await fetch("/analyze_portfolio", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(formData)
        });
        const result = await response.json();
        document.getElementById("result").innerHTML = `<h3>Portfolio Analysis</h3><p>${result.analysis}</p>`;
    } catch (error) {
        console.error("Error:", error);
    }
});
