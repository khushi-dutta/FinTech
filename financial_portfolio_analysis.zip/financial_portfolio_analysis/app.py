from flask import Flask, render_template, request, jsonify
import openai

app = Flask(__name__)

openai.api_key = "your-openai-api-key"

class PortfolioData:
    def __init__(self, monthly_income, monthly_expenses, total_debts, total_assets, financial_goals, risk_tolerance, current_investments, other_info):
        self.monthly_income = monthly_income
        self.monthly_expenses = monthly_expenses
        self.total_debts = total_debts
        self.total_assets = total_assets
        self.financial_goals = financial_goals
        self.risk_tolerance = risk_tolerance
        self.current_investments = current_investments
        self.other_info = other_info

def create_portfolio_prompt(portfolio: PortfolioData) -> str:
    return f"""Please analyze the user's financial portfolio based on the following data:
1. Monthly Income: ${portfolio.monthly_income:,}
2. Monthly Expenses: ${portfolio.monthly_expenses:,}
3. Total Debts: ${portfolio.total_debts:,}
4. Total Assets: ${portfolio.total_assets:,}
5. Financial Goals: '{portfolio.financial_goals}'
6. Risk Tolerance: {portfolio.risk_tolerance}
7. Current Investments: '{portfolio.current_investments}'
8. Other Financial Information: '{portfolio.other_info}'
- Financial health, savings rate, and debt ratio
- Investment strategies
- Recommended asset allocation based on risk
- Steps to achieve financial goals (e.g., retirement, home)"""

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/analyze_portfolio", methods=["POST"])
def analyze_portfolio():
    data = request.json
    portfolio = PortfolioData(
        monthly_income=float(data['monthly_income']),
        monthly_expenses=float(data['monthly_expenses']),
        total_debts=float(data['total_debts']),
        total_assets=float(data['total_assets']),
        financial_goals=data['financial_goals'],
        risk_tolerance=data['risk_tolerance'],
        current_investments=data['current_investments'],
        other_info=data['other_info']
    )

    prompt = create_portfolio_prompt(portfolio)
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": prompt}],
        max_tokens=150
    )
    analysis = response.choices[0].message['content'].strip()

    return jsonify({"analysis": analysis})

if __name__ == "__main__":
    app.run(debug=True)
