from flask import Flask, render_template, request, jsonify
from openai import OpenAI

app = Flask(__name__)

# Initialize the OpenAI client
client = OpenAI(api_key="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")

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/generate_plan", methods=["POST"])
def generate_plan():
    try:
        data = request.json
        
        # Construct a detailed prompt for the financial analysis
        prompt = f"""
        As a financial advisor, analyze the following financial information:
        {data}
        
        Please provide:
        1. A detailed budget analysis including:
           - Income vs expenses breakdown
           - Spending patterns
           - Areas of concern
           - Potential savings opportunities
        
        2. Specific, actionable recommendations including:
           - Short-term financial goals
           - Long-term investment strategies
           - Debt management advice
           - Specific savings targets
           - Risk management suggestions
        
        Format the response in clear sections.
        """

        # Make the API call to OpenAI
        response = client.chat.completions.create(
            model="gpt-4",  # or "gpt-3.5-turbo" depending on your needs
            messages=[
                {"role": "system", "content": "You are a professional financial advisor providing detailed, personalized financial analysis and recommendations."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.7
        )

        # Extract the response
        analysis = response.choices[0].message.content
        
        # Split the response into sections (you might need to adjust this based on the actual response format)
        sections = analysis.split("\n\n")
        budget_insights = sections[0] if sections else "Analysis not available"
        recommendations = "\n".join(sections[1:]) if len(sections) > 1 else "Recommendations not available"

        return jsonify({
            "budgetInsights": budget_insights,
            "recommendations": recommendations
        })

    except Exception as e:
        print("Error occurred:", str(e))
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(debug=True)