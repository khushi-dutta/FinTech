async function submitData() {
    const data = {
      income: document.getElementById("income").value,
      expenses: document.getElementById("expenses").value,
      debts: document.getElementById("debts").value,
      assets: document.getElementById("assets").value,
      goals: document.getElementById("goals").value,
      risks: document.getElementById("risks").value
    };
  
    try {
      const response = await fetch("/generate_plan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
      });
      const result = await response.json();
      document.getElementById("budgetInsights").textContent = result.budgetInsights;
      document.getElementById("recommendations").textContent = result.recommendations;
    } catch (error) {
      console.error("Error:", error);
    }
  }
  